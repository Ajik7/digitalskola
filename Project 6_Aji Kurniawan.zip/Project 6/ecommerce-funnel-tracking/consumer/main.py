import json
from kafka import KafkaConsumer
from sqlalchemy import create_engine, Text

engine=create_engine("postgresql://postgres:postgres@postgres:5432")

#Data Structure
"""
{
    "core": {
        "page_type":str,
        "page_url":str
        },
    "user": {
        "user_id":int,
        "session_id":str
        },
    "event_timestamp":int
    }
"""
    
consumer=KafkaConsumer(
    "ecommerce.tracker",
    auto_offset_reset = "earliest",
    bootstrap_servers = ["kafka:9092"],
    value_deserializer = lambda m: json.loads(m.decode("utf-8"))
)

for message in consumer:
    """print(message.value)
    with open("result.json","a") as file:
        file.write(json.dumps(message.value))
        file.write("\n")"""
    json_data = message.value
    event = {
        "page_type": json_data["core"]["page_type"],#page_type 
        "page_url": json_data["core"]["page_url"],#page_type 
        "user_id": json_data["user"]["user_id"],#page_type 
        "session_id": json_data["user"]["session_id"],#page_type 
        "event_timestamp": json_data["event_timestamp"],#page_type 
    }   
    with engine.begin() as conn:
        conn.execute(
            text("INSERT INTO events VALUES (:page_type, :page_url, :user_id, :session_id, :event_timestamp)"),
        )